
#!/bin/bash

module load netcdf/4.3.3.1

rundir='./'
cd $rundir
cp site.nml.historical site.nml
cp cable.nml.cable_casa_POP_historical cable.nml


cp pop_Cumberland_ini_transient.nc pop_Cumberland_ini.nc
cp Cumberland_climate_rst_transient.nc Cumberland_climate_rst.nc
cp Cumberland_casa_rst_transient.nc Cumberland_casa_rst.nc
cp Cumberland_cable_rst_transient.nc Cumberland_cable_rst.nc

logfile='log_historical'
$rundir/cable >& $logfile




mv Cumberland_out_cable.nc Cumberland_out_cable_historical.nc






