
#!/bin/bash

module load netcdf/4.3.3.1

rundir='./'
cd $rundir
cp site.nml.transient site.nml
cp cable.nml.cable_casa_POP_transient cable.nml


logfile='log_transient'
$rundir/cable >& $logfile

cp pop_Cumberland_ini.nc pop_Cumberland_ini_transient.nc
cp Cumberland_climate_rst.nc Cumberland_climate_rst_transient.nc
cp Cumberland_casa_rst.nc Cumberland_casa_rst_transient.nc
cp Cumberland_cable_rst.nc Cumberland_cable_rst_transient.nc
mv Cumberland_out_cable.nc Cumberland_out_cable_transient.nc




